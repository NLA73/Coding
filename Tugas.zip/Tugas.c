#include <stdio.h>
int a,b,t;
a = 10;
b = 5;
void main(){
    printf("a = %d\n", a);
    printf("b = %d\n", b);
    printf("Hasil dari a+b = %d\n", a+b);
    printf("Hasil dari a-b = %d\n", a-b);
    printf("Hasil dari axb = %d\n", a*b);
    printf("Hasil dari a/b = %d\n", a/b);
}

